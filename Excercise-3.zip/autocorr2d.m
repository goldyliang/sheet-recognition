function A = autocorr2d( h )

Fh = fft2(h);
A=ifft2(Fh.*conj(Fh));

end

