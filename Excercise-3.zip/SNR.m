function SNR_dB = SNR( img_orig, img )
    SNR_dB = 10 * log ( var (img_orig) / var(img - img_orig) );
end

