% Read the image and change to double grayscale (0-1)
I = im2double(rgb2gray((imread ('lena.bmp'))));
subplot(2,3,1); imshow(I);title('Figure 1: Original')

% Parameters of the motion blurring
len = 20;
theta=30;

% -----------------------------
% a) Simulate and apply motion blurring
PSF = fspecial('motion', len, theta);
blurred = imfilter(I, PSF, 'conv', 'circular');
subplot(2,3,2); imshow(blurred); title('Figure 2: Blurred with motion')

% -----------------------------
% b) Simulate and apply additive noise
% Apply noise
n_var_graylevel = 0.25;  % this is in the unit of gray level (0-255)
n_var = n_var_graylevel / 256.0;  % change to the normalized variant (0-1)

n = randn(size(I,1), size(I,2)) * n_var; % Noise with normal distribution
noised = blurred + n; % Image with addition noise on top of blured image

% The SNR in DB for the blurred and noised image
SNR0 = SNR (I, noised - I);

subplot(2,3,3); imshow(noised); 
stitle=sprintf('Figure 3: Blurred + Noise, \nSNR = %.2f dB ',SNR0);
title(stitle)


% ------------------------------
% c) Use autocorrelation functions and Wenier filter to restore

% --- Use matlab function ---
%corr_n = autocorr2d(n);
%corr_I = autocorr2d(I);

% Apply Wenier filter
%restore_w_autocorr = deconvwnr(noised, PSF, corr_n, corr_I);

% --- Use my function ---
N_pwr = fft2(n) .* conj(fft2(n));
I_pwr = fft2(I) .* conj(fft2(I));
restore_w_autocorr = my_wiener_restore(noised, PSF, N_pwr, I_pwr);
SNR_w_autocorr = SNR (I, restore_w_autocorr);

subplot(2,3,4); imshow(restore_w_autocorr); 
stitle=sprintf('Figure 4: Restored w autocorrelation func,\nSNR = %.2f dB', SNR_w_autocorr);
title(stitle)


% ------------------------------
% d) e) Use only estimated nsr as input to Wenier filter

% Get an estimated nsr as input to Wenier filter
estimated_nsr = n_var / var (I(:));
%restore_nsr_only = deconvwnr(noised, PSF, estimated_nsr);
restore_nsr_only = my_wiener_restore(noised, PSF, n_var, var (I(:)));
SNR_w_nsr_only = SNR (I, restore_nsr_only);

subplot(2,3,5); imshow(restore_nsr_only); 
stitle=sprintf('Figure 5: Restored with nsr \n Estimated nsr = %.2f, \nSNR = %.2f dB', estimated_nsr, SNR_w_nsr_only);
title(stitle)

% ------------------------------
% Try to apply another estimated nsr as input
% Assuming the original image has standard deviation of 60 (gray levels),
% which is normalized to 60 / 256, and the variation is the (60/256)^2
estimated_nsr = n_var / ((60 / 256)^2); 

%restore_nsr_only = deconvwnr(noised, PSF, estimated_nsr);
restore_nsr_only = my_wiener_restore(noised, PSF, n_var, (60 / 256)^2);
SNR_w_nsr_only = SNR (I, restore_nsr_only);

subplot(2,3,6); imshow(restore_nsr_only); 
stitle=sprintf('Figure 6: Restored with nsr\n Estimated nsr = %.2f, \nSNR = %.2f dB', estimated_nsr, SNR_w_nsr_only);
title(stitle)
