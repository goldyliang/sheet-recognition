function img_restored = my_wiener_restore( img, h, N, F)

    % Pad the PSF to the same size of img and do a circularly shift
    padSize = size(img) - size(h);
    h1 = padarray(h, padSize, 'post');
    h1 = circshift(h1,-floor(size(h)/2));
    H = fft2(h1);
    
    % Fourier transform of the image
    G = fft2(img);
    
    % Fourier transform of the restored image
    Fr = zeros(size(img));
    
    % Calculate Fr(u,v) one by one
    for u = 1:size(img,1)
        for v = 1:size(img,2)
            
            % Get the power ratio from either single scalar value, or 
            % the element of autocorrelation function
            if (size(N) == 1)
                Sn = N;
            else
                Sn = N(u, v);
            end
            
            if (size(F) == 1)
                Sf = F;
            else
                Sf = F(u,v);
            end
            
            H2 = abs(H(u,v)*H(u,v));
            Fr (u, v) = conj(H(u,v)) * Sf * G(u,v) / (H2 * Sf + Sn);
            
        end
    end
    
    img_restored = real(ifft2 (Fr));

end

